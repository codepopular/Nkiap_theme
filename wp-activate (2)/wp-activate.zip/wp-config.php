<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'unique_it');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'r!Te2~qb:Ftm#&c[7Zm9TFa@4qO>@T2B@S;9b.[7k7zR=9 AXl? Q)W<)6;>-Le*');
define('SECURE_AUTH_KEY',  'M 5(M#On`<b_f^2;-)~5l~MvGl4crr.[+:N.p$9GtCYn5Fvu+ L]E-PM-Ke9_3iY');
define('LOGGED_IN_KEY',    '[F43H~9MnjJ,4-`suaOvD{q[E~RWMNVZH`2pZ)}16@Ur&F{Y!*lBtq&rTBe1&KkU');
define('NONCE_KEY',        'XW>wvtV<^,CX}N=%r YjecWuG+/3,;R|3GII`jcqa<zzJsT-rMn}{V0}m[` 0AWF');
define('AUTH_SALT',        '!9dO1vg+Cs6U+FiU7;KiDcY? 5[tIh}iT7_VFZ:9Vl@gjS4~ayB#/4@Tfs9T~nT,');
define('SECURE_AUTH_SALT', 'R<CoE+y?x?yOv^-;As9AUFzv~rpvrtpKL1{,<c~P{g/}]aT@D$~^>sY?u3]X[>G2');
define('LOGGED_IN_SALT',   'Ub_ePd,@^c51;XS,s/XpB=uJ}rv%B-TxiGa@8_?pePCTyF![3!vqz!pud_A#=9$j');
define('NONCE_SALT',       'i2G[r}ynFcUp.D4i-2Sva)?*a5<Upm.LFWkZlR^PAfe1oNKFQ:VX8pDF?%kX#X8i');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

set_time_limit(300);


/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
