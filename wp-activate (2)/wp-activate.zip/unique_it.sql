-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2018 at 03:10 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unique_it`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-12-11 06:00:31', '2018-12-11 06:00:31', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/unique', 'yes'),
(2, 'home', 'http://localhost/unique', 'yes'),
(3, 'blogname', 'yes ok', 'yes'),
(4, 'blogdescription', 'Home', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'wweshahidul@gmial.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:89:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:27:\"js_composer/js_composer.php\";i:1;s:25:\"menu-icons/menu-icons.php\";i:2;s:41:\"page-or-post-clone/page-or-post-clone.php\";i:3;s:43:\"shortcodes-ultimate/shortcodes-ultimate.php\";i:4;s:28:\"widgets-in-menu/yawp-wim.php\";i:5;s:31:\"wp-html-block/wp-html-block.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'unique', 'yes'),
(41, 'stylesheet', 'unique', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:8:\"yawp_wim\";a:2:{i:0;s:13:\"custom_html-2\";i:1;s:13:\"custom_html-3\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:3:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:2412:\"      <ul class=\"submenu\">\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"> <i class=\"fa fa-paint-brush\" aria-hidden=\"true\"></i>\r\n                                        Outsourcing</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Auto Card\r\n                                        (2d, 3d)</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-desktop\" aria-hidden=\"true\"></i>\r\n                                        Computer Subject</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-bullhorn\" aria-hidden=\"true\"></i>\r\n                                        Office Proffesional Course</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-free-code-camp\" aria-hidden=\"true\"></i>\r\n                                        3d Studio Max</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-search\" aria-hidden=\"true\"></i> SEO</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i>\r\n                                        Graphic Design</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-mobile\" aria-hidden=\"true\"></i> App\r\n                                        Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-area-chart\" aria-hidden=\"true\"></i> Web\r\n                                        Desing And Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-american-sign-language-interpreting\"\r\n                                            aria-hidden=\"true\"></i> Wordpress Theme Development</a></li>\r\n			\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-university\" aria-hidden=\"true\"></i>Affiliate\r\n                                        Marketing</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-video-camera\" aria-hidden=\"true\"></i>\r\n                                        Video Editing & Sound Recording</a></li>\r\n                            </ul>\";}i:3;a:2:{s:5:\"title\";s:0:\"\";s:7:\"content\";s:1665:\"  <ul class=\"submenu\">\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"> <i class=\"fa fa-paint-brush\" aria-hidden=\"true\"></i>\r\n                                        Web Design & Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Software\r\n                                        Development </a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-desktop\" aria-hidden=\"true\"></i>\r\n                                        App Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-bullhorn\" aria-hidden=\"true\"></i>\r\n                                        Domain & Hosting Registration</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-free-code-camp\" aria-hidden=\"true\"></i>\r\n                                        Software Customazition</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-search\" aria-hidden=\"true\"></i> SEO &\r\n                                        Internet Marketing</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i>\r\n                                        ERP Software Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-mobile\" aria-hidden=\"true\"></i>\r\n                                        Multimedia & Graphic Design</a></li>\r\n                            </ul>\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1544875232;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1544896832;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1544940057;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1544940513;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1544514221;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(124, '_site_transient_timeout_browser_4f580420fc30ef32385315403354ff54', '1545112845', 'no'),
(125, '_site_transient_browser_4f580420fc30ef32385315403354ff54', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"63.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(128, 'can_compress_scripts', '1', 'no'),
(145, 'recently_activated', 'a:1:{s:31:\"wp-menu-icons/wp-menu-icons.php\";i:1544722674;}', 'yes'),
(154, 'category_children', 'a:0:{}', 'yes'),
(160, 'theme_mods_twentyfifteen', 'a:7:{s:18:\"custom_css_post_id\";i:-1;s:17:\"sidebar_textcolor\";s:7:\"#111111\";s:23:\"header_background_color\";s:7:\"#ffdf00\";s:16:\"background_color\";s:6:\"f4ca16\";s:12:\"color_scheme\";s:6:\"yellow\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1544695781;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"nav_menu_locations\";a:0:{}}', 'yes'),
(163, 'current_theme', '', 'yes'),
(164, 'theme_switched', '', 'yes'),
(165, 'theme_switched_via_customizer', '', 'yes'),
(166, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(168, '_transient_twentyseventeen_categories', '1', 'yes'),
(170, '_transient_twentyfifteen_categories', '1', 'yes'),
(177, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.1\";s:7:\"version\";s:5:\"5.0.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.1\";s:7:\"version\";s:5:\"5.0.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1544871871;s:15:\"version_checked\";s:5:\"4.9.9\";s:12:\"translations\";a:0:{}}', 'no'),
(179, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:21:\"wweshahidul@gmial.com\";s:7:\"version\";s:5:\"4.9.9\";s:9:\"timestamp\";i:1544683053;}', 'no'),
(196, 'theme_mods_unique', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:8:\"mainmenu\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1544695778;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(200, 'WPLANG', '', 'yes'),
(201, 'new_admin_email', 'wweshahidul@gmial.com', 'yes'),
(214, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:1:{i:0;i:2;}}', 'yes'),
(215, '_site_transient_timeout_browser_7c536d82012ce7c421315e5571540a1e', '1545312797', 'no'),
(216, '_site_transient_browser_7c536d82012ce7c421315e5571540a1e', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"70.0.3538.110\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(227, '_transient_timeout_plugin_slugs', '1544887391', 'no'),
(228, '_transient_plugin_slugs', 'a:8:{i:0;s:19:\"akismet/akismet.php\";i:1;s:41:\"page-or-post-clone/page-or-post-clone.php\";i:2;s:23:\"gutenberg/gutenberg.php\";i:3;s:25:\"menu-icons/menu-icons.php\";i:4;s:43:\"shortcodes-ultimate/shortcodes-ultimate.php\";i:5;s:28:\"widgets-in-menu/yawp-wim.php\";i:6;s:27:\"js_composer/js_composer.php\";i:7;s:31:\"wp-html-block/wp-html-block.php\";}', 'no'),
(232, 'vc_version', '5.5.2', 'yes'),
(235, 'menu_icons_install', '1544723252', 'yes'),
(236, '_transient_timeout_menu_icons_0112versions', '1547315253', 'no'),
(237, '_transient_menu_icons_0112versions', 'a:30:{i:0;a:2:{s:7:\"version\";s:5:\"0.1.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.1.0.zip\";}i:1;a:2:{s:7:\"version\";s:5:\"0.1.1\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.1.1.zip\";}i:2;a:2:{s:7:\"version\";s:5:\"0.1.2\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.1.2.zip\";}i:3;a:2:{s:7:\"version\";s:5:\"0.1.3\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.1.3.zip\";}i:4;a:2:{s:7:\"version\";s:5:\"0.1.4\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.1.4.zip\";}i:5;a:2:{s:7:\"version\";s:5:\"0.1.5\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.1.5.zip\";}i:6;a:2:{s:7:\"version\";s:6:\"0.10.0\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.10.0.zip\";}i:7;a:2:{s:7:\"version\";s:6:\"0.10.1\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.10.1.zip\";}i:8;a:2:{s:7:\"version\";s:6:\"0.10.2\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.10.2.zip\";}i:9;a:2:{s:7:\"version\";s:6:\"0.11.0\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.11.0.zip\";}i:10;a:2:{s:7:\"version\";s:6:\"0.11.1\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.11.1.zip\";}i:11;a:2:{s:7:\"version\";s:6:\"0.11.2\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.11.2.zip\";}i:12;a:2:{s:7:\"version\";s:6:\"0.11.3\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.11.3.zip\";}i:13;a:2:{s:7:\"version\";s:6:\"0.11.4\";s:3:\"url\";s:60:\"https://downloads.wordpress.org/plugin/menu-icons.0.11.4.zip\";}i:14;a:2:{s:7:\"version\";s:5:\"0.2.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.2.0.zip\";}i:15;a:2:{s:7:\"version\";s:5:\"0.2.1\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.2.1.zip\";}i:16;a:2:{s:7:\"version\";s:5:\"0.2.2\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.2.2.zip\";}i:17;a:2:{s:7:\"version\";s:5:\"0.2.3\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.2.3.zip\";}i:18;a:2:{s:7:\"version\";s:5:\"0.3.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.3.0.zip\";}i:19;a:2:{s:7:\"version\";s:5:\"0.3.1\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.3.1.zip\";}i:20;a:2:{s:7:\"version\";s:5:\"0.3.2\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.3.2.zip\";}i:21;a:2:{s:7:\"version\";s:5:\"0.4.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.4.0.zip\";}i:22;a:2:{s:7:\"version\";s:5:\"0.5.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.5.0.zip\";}i:23;a:2:{s:7:\"version\";s:5:\"0.5.1\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.5.1.zip\";}i:24;a:2:{s:7:\"version\";s:5:\"0.6.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.6.0.zip\";}i:25;a:2:{s:7:\"version\";s:5:\"0.7.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.7.0.zip\";}i:26;a:2:{s:7:\"version\";s:5:\"0.8.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.8.0.zip\";}i:27;a:2:{s:7:\"version\";s:5:\"0.8.1\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.8.1.zip\";}i:28;a:2:{s:7:\"version\";s:5:\"0.9.0\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.9.0.zip\";}i:29;a:2:{s:7:\"version\";s:5:\"0.9.2\";s:3:\"url\";s:59:\"https://downloads.wordpress.org/plugin/menu-icons.0.9.2.zip\";}}', 'no'),
(252, 'menu-icons', 'a:2:{s:6:\"global\";a:1:{s:10:\"icon_types\";a:1:{i:0;s:2:\"fa\";}}s:6:\"menu_2\";a:6:{s:10:\"hide_label\";s:0:\"\";s:8:\"position\";s:6:\"before\";s:14:\"vertical_align\";s:6:\"middle\";s:9:\"font_size\";s:3:\"1.2\";s:9:\"svg_width\";s:1:\"1\";s:10:\"image_size\";s:9:\"thumbnail\";}}', 'yes'),
(257, 'su_option_custom-formatting', 'on', 'no'),
(258, 'su_option_skip', 'on', 'no'),
(259, 'su_option_prefix', 'su_', 'no'),
(260, 'su_option_custom-css', '', 'no'),
(261, 'su_option_supported_blocks', 'a:3:{i:0;s:14:\"core/paragraph\";i:1;s:14:\"core/shortcode\";i:2;s:13:\"core/freeform\";}', 'no'),
(262, 'widget_shortcodes-ultimate', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(263, 'su_option_version', '5.1.1', 'no'),
(264, 'su_option_dismissed_notices', 'a:1:{s:4:\"rate\";i:1545329874;}', 'yes'),
(265, '_transient_timeout_su/generator/popup', '1544971406', 'no'),
(266, '_transient_su/generator/popup', '	<div id=\"su-generator-wrap\" style=\"display:none\">\n		<div id=\"su-generator\">\n			<div id=\"su-generator-header\">\n				<div id=\"su-generator-tools\"><a href=\"http://localhost/unique/wp-admin/admin.php?page=shortcodes-ultimate#tab-1\" target=\"_blank\" title=\"Settings\">Plugin settings</a> <span></span> <a href=\"http://gndev.info/shortcodes-ultimate/\" target=\"_blank\" title=\"Plugin homepage\">Plugin homepage</a> <span></span> <a href=\"http://wordpress.org/support/plugin/shortcodes-ultimate/\" target=\"_blank\" title=\"Support forums\">Support forums</a> <span></span> <a href=\"http://localhost/unique/wp-admin/admin.php?page=shortcodes-ultimate-addons\" target=\"_blank\" title=\"Add-ons\" class=\"su-add-ons\">Add-ons</a></div>\n				<input type=\"text\" name=\"su_generator_search\" id=\"su-generator-search\" value=\"\" placeholder=\"Search for shortcodes\" />\n				<p id=\"su-generator-search-pro-tip\"><strong>Pro Tip:</strong> Hit enter to select highlighted shortcode, while searching</p>\n				<div id=\"su-generator-filter\">\n					<strong>Filter by type</strong>\n					<a href=\"#\" data-filter=\"all\">All</a><a href=\"#\" data-filter=\"content\">Content</a><a href=\"#\" data-filter=\"box\">Box</a><a href=\"#\" data-filter=\"media\">Media</a><a href=\"#\" data-filter=\"gallery\">Gallery</a><a href=\"#\" data-filter=\"data\">Data</a><a href=\"#\" data-filter=\"other\">Other</a>				</div>\n				<div id=\"su-generator-choices\" class=\"su-generator-clearfix\">\n					<span data-name=\"Heading\" data-shortcode=\"heading\" title=\"Styled heading\" data-desc=\"Styled heading\" data-group=\"content\"><i class=\"fa fa-h-square\" style=\"\" aria-label=\"\"></i>Heading</span>\n<span data-name=\"Tabs\" data-shortcode=\"tabs\" title=\"Tabs container\" data-desc=\"Tabs container\" data-group=\"box\"><i class=\"fa fa-list-alt\" style=\"\" aria-label=\"\"></i>Tabs</span>\n<span data-name=\"Tab\" data-shortcode=\"tab\" title=\"Single tab\" data-desc=\"Single tab\" data-group=\"box\"><i class=\"fa fa-list-alt\" style=\"\" aria-label=\"\"></i>Tab</span>\n<span data-name=\"Spoiler\" data-shortcode=\"spoiler\" title=\"Spoiler with hidden content\" data-desc=\"Spoiler with hidden content\" data-group=\"box\"><i class=\"fa fa-list-ul\" style=\"\" aria-label=\"\"></i>Spoiler</span>\n<span data-name=\"Accordion\" data-shortcode=\"accordion\" title=\"Accordion with spoilers\" data-desc=\"Accordion with spoilers\" data-group=\"box\"><i class=\"fa fa-list\" style=\"\" aria-label=\"\"></i>Accordion</span>\n<span data-name=\"Divider\" data-shortcode=\"divider\" title=\"Content divider with optional TOP link\" data-desc=\"Content divider with optional TOP link\" data-group=\"content\"><i class=\"fa fa-ellipsis-h\" style=\"\" aria-label=\"\"></i>Divider</span>\n<span data-name=\"Spacer\" data-shortcode=\"spacer\" title=\"Empty space with adjustable height\" data-desc=\"Empty space with adjustable height\" data-group=\"content other\"><i class=\"fa fa-arrows-v\" style=\"\" aria-label=\"\"></i>Spacer</span>\n<span data-name=\"Highlight\" data-shortcode=\"highlight\" title=\"Highlighted text\" data-desc=\"Highlighted text\" data-group=\"content\"><i class=\"fa fa-pencil\" style=\"\" aria-label=\"\"></i>Highlight</span>\n<span data-name=\"Label\" data-shortcode=\"label\" title=\"Styled label\" data-desc=\"Styled label\" data-group=\"content\"><i class=\"fa fa-tag\" style=\"\" aria-label=\"\"></i>Label</span>\n<span data-name=\"Quote\" data-shortcode=\"quote\" title=\"Blockquote alternative\" data-desc=\"Blockquote alternative\" data-group=\"box\"><i class=\"fa fa-quote-right\" style=\"\" aria-label=\"\"></i>Quote</span>\n<span data-name=\"Pullquote\" data-shortcode=\"pullquote\" title=\"Pullquote\" data-desc=\"Pullquote\" data-group=\"box\"><i class=\"fa fa-quote-left\" style=\"\" aria-label=\"\"></i>Pullquote</span>\n<span data-name=\"Dropcap\" data-shortcode=\"dropcap\" title=\"Dropcap\" data-desc=\"Dropcap\" data-group=\"content\"><i class=\"fa fa-bold\" style=\"\" aria-label=\"\"></i>Dropcap</span>\n<span data-name=\"Columns\" data-shortcode=\"row\" title=\"Row for flexible columns\" data-desc=\"Row for flexible columns\" data-group=\"box\"><i class=\"fa fa-columns\" style=\"\" aria-label=\"\"></i>Columns</span>\n<span data-name=\"Column\" data-shortcode=\"column\" title=\"Flexible and responsive columns\" data-desc=\"Flexible and responsive columns\" data-group=\"box\"><i class=\"fa fa-columns\" style=\"\" aria-label=\"\"></i>Column</span>\n<span data-name=\"List\" data-shortcode=\"list\" title=\"Styled unordered list\" data-desc=\"Styled unordered list\" data-group=\"content\"><i class=\"fa fa-list-ol\" style=\"\" aria-label=\"\"></i>List</span>\n<span data-name=\"Button\" data-shortcode=\"button\" title=\"Styled button\" data-desc=\"Styled button\" data-group=\"content\"><i class=\"fa fa-heart\" style=\"\" aria-label=\"\"></i>Button</span>\n<span data-name=\"Service\" data-shortcode=\"service\" title=\"Service box with title\" data-desc=\"Service box with title\" data-group=\"box\"><i class=\"fa fa-check-square-o\" style=\"\" aria-label=\"\"></i>Service</span>\n<span data-name=\"Box\" data-shortcode=\"box\" title=\"Colored box with caption\" data-desc=\"Colored box with caption\" data-group=\"box\"><i class=\"fa fa-list-alt\" style=\"\" aria-label=\"\"></i>Box</span>\n<span data-name=\"Note\" data-shortcode=\"note\" title=\"Colored box\" data-desc=\"Colored box\" data-group=\"box\"><i class=\"fa fa-list-alt\" style=\"\" aria-label=\"\"></i>Note</span>\n<span data-name=\"Expand\" data-shortcode=\"expand\" title=\"Expandable text block\" data-desc=\"Expandable text block\" data-group=\"box\"><i class=\"fa fa-sort-amount-asc\" style=\"\" aria-label=\"\"></i>Expand</span>\n<span data-name=\"Lightbox\" data-shortcode=\"lightbox\" title=\"Lightbox window with custom content\" data-desc=\"Lightbox window with custom content\" data-group=\"gallery\"><i class=\"fa fa-external-link\" style=\"\" aria-label=\"\"></i>Lightbox</span>\n<span data-name=\"Lightbox content\" data-shortcode=\"lightbox_content\" title=\"Inline content for lightbox\" data-desc=\"Inline content for lightbox\" data-group=\"gallery\"><i class=\"fa fa-external-link\" style=\"\" aria-label=\"\"></i>Lightbox content</span>\n<span data-name=\"Tooltip\" data-shortcode=\"tooltip\" title=\"Tooltip window with custom content\" data-desc=\"Tooltip window with custom content\" data-group=\"other\"><i class=\"fa fa-comment-o\" style=\"\" aria-label=\"\"></i>Tooltip</span>\n<span data-name=\"Private\" data-shortcode=\"private\" title=\"Private note for post authors. Any content wrapped with this shortcode will only be visible to post authors (users with publish_posts capability).\" data-desc=\"Private note for post authors. Any content wrapped with this shortcode will only be visible to post authors (users with publish_posts capability).\" data-group=\"other\"><i class=\"fa fa-lock\" style=\"\" aria-label=\"\"></i>Private</span>\n<span data-name=\"YouTube\" data-shortcode=\"youtube\" title=\"YouTube video\" data-desc=\"YouTube video\" data-group=\"media\"><i class=\"fa fa-youtube-play\" style=\"\" aria-label=\"\"></i>YouTube</span>\n<span data-name=\"YouTube advanced\" data-shortcode=\"youtube_advanced\" title=\"YouTube video player with advanced settings\" data-desc=\"YouTube video player with advanced settings\" data-group=\"media\"><i class=\"fa fa-youtube-play\" style=\"\" aria-label=\"\"></i>YouTube advanced</span>\n<span data-name=\"Vimeo\" data-shortcode=\"vimeo\" title=\"Vimeo video\" data-desc=\"Vimeo video\" data-group=\"media\"><i class=\"fa fa-youtube-play\" style=\"\" aria-label=\"\"></i>Vimeo</span>\n<span data-name=\"Dailymotion\" data-shortcode=\"dailymotion\" title=\"Dailymotion video\" data-desc=\"Dailymotion video\" data-group=\"media\"><i class=\"fa fa-youtube-play\" style=\"\" aria-label=\"\"></i>Dailymotion</span>\n<span data-name=\"Audio\" data-shortcode=\"audio\" title=\"Custom audio player\" data-desc=\"Custom audio player\" data-group=\"media\"><i class=\"fa fa-play-circle\" style=\"\" aria-label=\"\"></i>Audio</span>\n<span data-name=\"Video\" data-shortcode=\"video\" title=\"Custom video player\" data-desc=\"Custom video player\" data-group=\"media\"><i class=\"fa fa-play-circle\" style=\"\" aria-label=\"\"></i>Video</span>\n<span data-name=\"Table\" data-shortcode=\"table\" title=\"Styled table from HTML or CSV file\" data-desc=\"Styled table from HTML or CSV file\" data-group=\"content\"><i class=\"fa fa-table\" style=\"\" aria-label=\"\"></i>Table</span>\n<span data-name=\"Permalink\" data-shortcode=\"permalink\" title=\"Permalink to specified post/page\" data-desc=\"Permalink to specified post/page\" data-group=\"content other\"><i class=\"fa fa-link\" style=\"\" aria-label=\"\"></i>Permalink</span>\n<span data-name=\"Members\" data-shortcode=\"members\" title=\"Content for logged in members only\" data-desc=\"Content for logged in members only\" data-group=\"other\"><i class=\"fa fa-lock\" style=\"\" aria-label=\"\"></i>Members</span>\n<span data-name=\"Guests\" data-shortcode=\"guests\" title=\"Content for guests only\" data-desc=\"Content for guests only\" data-group=\"other\"><i class=\"fa fa-user\" style=\"\" aria-label=\"\"></i>Guests</span>\n<span data-name=\"RSS feed\" data-shortcode=\"feed\" title=\"Feed grabber\" data-desc=\"Feed grabber\" data-group=\"content other\"><i class=\"fa fa-rss\" style=\"\" aria-label=\"\"></i>RSS feed</span>\n<span data-name=\"Menu\" data-shortcode=\"menu\" title=\"Custom menu by name\" data-desc=\"Custom menu by name\" data-group=\"other\"><i class=\"fa fa-bars\" style=\"\" aria-label=\"\"></i>Menu</span>\n<span data-name=\"Sub pages\" data-shortcode=\"subpages\" title=\"List of sub pages\" data-desc=\"List of sub pages\" data-group=\"other\"><i class=\"fa fa-bars\" style=\"\" aria-label=\"\"></i>Sub pages</span>\n<span data-name=\"Siblings\" data-shortcode=\"siblings\" title=\"List of cureent page siblings\" data-desc=\"List of cureent page siblings\" data-group=\"other\"><i class=\"fa fa-bars\" style=\"\" aria-label=\"\"></i>Siblings</span>\n<span data-name=\"Document\" data-shortcode=\"document\" title=\"Document viewer by Google\" data-desc=\"Document viewer by Google\" data-group=\"media\"><i class=\"fa fa-file-text\" style=\"\" aria-label=\"\"></i>Document</span>\n<span data-name=\"Google map\" data-shortcode=\"gmap\" title=\"Maps by Google\" data-desc=\"Maps by Google\" data-group=\"media\"><i class=\"fa fa-globe\" style=\"\" aria-label=\"\"></i>Google map</span>\n<span data-name=\"Slider\" data-shortcode=\"slider\" title=\"Customizable image slider\" data-desc=\"Customizable image slider\" data-group=\"gallery\"><i class=\"fa fa-picture-o\" style=\"\" aria-label=\"\"></i>Slider</span>\n<span data-name=\"Carousel\" data-shortcode=\"carousel\" title=\"Customizable image carousel\" data-desc=\"Customizable image carousel\" data-group=\"gallery\"><i class=\"fa fa-picture-o\" style=\"\" aria-label=\"\"></i>Carousel</span>\n<span data-name=\"Gallery\" data-shortcode=\"custom_gallery\" title=\"Customizable image gallery\" data-desc=\"Customizable image gallery\" data-group=\"gallery\"><i class=\"fa fa-picture-o\" style=\"\" aria-label=\"\"></i>Gallery</span>\n<span data-name=\"Posts\" data-shortcode=\"posts\" title=\"Custom posts query with customizable template\" data-desc=\"Custom posts query with customizable template\" data-group=\"other\"><i class=\"fa fa-th-list\" style=\"\" aria-label=\"\"></i>Posts</span>\n<span data-name=\"Dummy text\" data-shortcode=\"dummy_text\" title=\"Text placeholder\" data-desc=\"Text placeholder\" data-group=\"content\"><i class=\"fa fa-text-height\" style=\"\" aria-label=\"\"></i>Dummy text</span>\n<span data-name=\"Dummy image\" data-shortcode=\"dummy_image\" title=\"Image placeholder with random image\" data-desc=\"Image placeholder with random image\" data-group=\"content\"><i class=\"fa fa-picture-o\" style=\"\" aria-label=\"\"></i>Dummy image</span>\n<span data-name=\"Animation\" data-shortcode=\"animate\" title=\"Wrapper for animation. Any nested element will be animated\" data-desc=\"Wrapper for animation. Any nested element will be animated\" data-group=\"other\"><i class=\"fa fa-bolt\" style=\"\" aria-label=\"\"></i>Animation</span>\n<span data-name=\"Meta data\" data-shortcode=\"meta\" title=\"Post meta\" data-desc=\"Post meta\" data-group=\"data\"><i class=\"fa fa-info-circle\" style=\"\" aria-label=\"\"></i>Meta data</span>\n<span data-name=\"User data\" data-shortcode=\"user\" title=\"User data\" data-desc=\"User data\" data-group=\"data\"><i class=\"fa fa-info-circle\" style=\"\" aria-label=\"\"></i>User data</span>\n<span data-name=\"Post data\" data-shortcode=\"post\" title=\"The utility shortcode to display various post data, like post title, status or excerpt\" data-desc=\"The utility shortcode to display various post data, like post title, status or excerpt\" data-group=\"data\"><i class=\"fa fa-info-circle\" style=\"\" aria-label=\"\"></i>Post data</span>\n<span data-name=\"Template\" data-shortcode=\"template\" title=\"Theme template\" data-desc=\"Theme template\" data-group=\"other\"><i class=\"fa fa-puzzle-piece\" style=\"\" aria-label=\"\"></i>Template</span>\n<span data-name=\"QR code\" data-shortcode=\"qrcode\" title=\"Advanced QR code generator\" data-desc=\"Advanced QR code generator\" data-group=\"content\"><i class=\"fa fa-qrcode\" style=\"\" aria-label=\"\"></i>QR code</span>\n<span data-name=\"Scheduler\" data-shortcode=\"scheduler\" title=\"Allows to show the content only at the specified time period\" data-desc=\"Allows to show the content only at the specified time period\" data-group=\"other\"><i class=\"fa fa-clock-o\" style=\"\" aria-label=\"\"></i>Scheduler</span>\n				</div>\n			</div>\n			<div id=\"su-generator-settings\"></div>\n			<input type=\"hidden\" name=\"su-generator-selected\" id=\"su-generator-selected\" value=\"http://localhost/unique/wp-content/plugins/shortcodes-ultimate\" />\n			<input type=\"hidden\" name=\"su-generator-url\" id=\"su-generator-url\" value=\"http://localhost/unique/wp-content/plugins/shortcodes-ultimate\" />\n			<input type=\"hidden\" name=\"su-compatibility-mode-prefix\" id=\"su-compatibility-mode-prefix\" value=\"su_\" />\n			<div id=\"su-generator-result\" style=\"display:none\"></div>\n		</div>\n	</div>\n', 'no'),
(278, '_transient_timeout_themeisle_sdk_feed_items', '1544971048', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(279, '_transient_themeisle_sdk_feed_items', 'a:5:{i:0;a:3:{s:5:\"title\";s:63:\"How to Create a Landing Page With the Block Editor in WordPress\";s:4:\"date\";i:1544694337;s:4:\"link\";s:81:\"https://themeisle.com/blog/create-a-landing-page-with-the-block-editor-wordpress/\";}i:1;a:3:{s:5:\"title\";s:85:\"How to Disable the Block Editor (aka Gutenberg) and Use the Previous WordPress Editor\";s:4:\"date\";i:1544607414;s:4:\"link\";s:53:\"https://themeisle.com/blog/previous-wordpress-editor/\";}i:2;a:3:{s:5:\"title\";s:57:\"What Is WordPress? WordPress 101, Explained for Beginners\";s:4:\"date\";i:1544526079;s:4:\"link\";s:49:\"https://themeisle.com/blog/what-is-wordpress-101/\";}i:3;a:3:{s:5:\"title\";s:63:\"How to Optimize Your WooCommerce Product Page in 4 Simple Steps\";s:4:\"date\";i:1544435467;s:4:\"link\";s:52:\"https://themeisle.com/blog/woocommerce-product-page/\";}i:4;a:3:{s:5:\"title\";s:64:\"Gutenberg Blocks: What They Are and How to Use Them in WordPress\";s:4:\"date\";i:1544089112;s:4:\"link\";s:54:\"https://themeisle.com/blog/gutenberg-blocks-explained/\";}}', 'no'),
(318, '_site_transient_timeout_theme_roots', '1544873676', 'no'),
(319, '_site_transient_theme_roots', 'a:4:{s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";s:6:\"unique\";s:7:\"/themes\";}', 'no'),
(320, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1544871880;s:7:\"checked\";a:4:{s:13:\"twentyfifteen\";s:3:\"2.1\";s:15:\"twentyseventeen\";s:3:\"1.8\";s:13:\"twentysixteen\";s:3:\"1.6\";s:6:\"unique\";s:0:\"\";}s:8:\"response\";a:1:{s:6:\"unique\";a:4:{s:5:\"theme\";s:6:\"unique\";s:11:\"new_version\";s:5:\"0.3.0\";s:3:\"url\";s:36:\"https://wordpress.org/themes/unique/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/theme/unique.0.3.0.zip\";}}s:12:\"translations\";a:0:{}}', 'no'),
(321, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1544871883;s:7:\"checked\";a:8:{s:19:\"akismet/akismet.php\";s:3:\"4.1\";s:41:\"page-or-post-clone/page-or-post-clone.php\";s:3:\"1.1\";s:23:\"gutenberg/gutenberg.php\";s:5:\"4.6.1\";s:25:\"menu-icons/menu-icons.php\";s:6:\"0.11.2\";s:43:\"shortcodes-ultimate/shortcodes-ultimate.php\";s:5:\"5.1.1\";s:28:\"widgets-in-menu/yawp-wim.php\";s:5:\"1.0.0\";s:27:\"js_composer/js_composer.php\";s:5:\"5.5.2\";s:31:\"wp-html-block/wp-html-block.php\";s:5:\"1.0.1\";}s:8:\"response\";a:3:{s:23:\"gutenberg/gutenberg.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:23:\"w.org/plugins/gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:6:\"plugin\";s:23:\"gutenberg/gutenberg.php\";s:11:\"new_version\";s:5:\"4.7.0\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/gutenberg/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/gutenberg.4.7.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/gutenberg/assets/icon-256x256.jpg?rev=1776042\";s:2:\"1x\";s:62:\"https://ps.w.org/gutenberg/assets/icon-128x128.jpg?rev=1776042\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/gutenberg/assets/banner-1544x500.jpg?rev=1718710\";s:2:\"1x\";s:64:\"https://ps.w.org/gutenberg/assets/banner-772x250.jpg?rev=1718710\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"menu-icons/menu-icons.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:24:\"w.org/plugins/menu-icons\";s:4:\"slug\";s:10:\"menu-icons\";s:6:\"plugin\";s:25:\"menu-icons/menu-icons.php\";s:11:\"new_version\";s:6:\"0.11.4\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/menu-icons/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/plugin/menu-icons.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:63:\"https://ps.w.org/menu-icons/assets/icon-128x128.png?rev=1797515\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/menu-icons/assets/banner-772x250.png?rev=1797515\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:3:\"5.0\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"js_composer/js_composer.php\";O:8:\"stdClass\":5:{s:4:\"slug\";s:11:\"js_composer\";s:11:\"new_version\";s:3:\"5.6\";s:3:\"url\";s:0:\"\";s:7:\"package\";b:0;s:4:\"name\";s:21:\"WPBakery Page Builder\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:5:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"4.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/akismet.4.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"page-or-post-clone/page-or-post-clone.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/page-or-post-clone\";s:4:\"slug\";s:18:\"page-or-post-clone\";s:6:\"plugin\";s:41:\"page-or-post-clone/page-or-post-clone.php\";s:11:\"new_version\";s:3:\"1.1\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/page-or-post-clone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/page-or-post-clone.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/page-or-post-clone/assets/icon-128x128.png?rev=1564270\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:73:\"https://ps.w.org/page-or-post-clone/assets/banner-772x250.png?rev=1404815\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"shortcodes-ultimate/shortcodes-ultimate.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/shortcodes-ultimate\";s:4:\"slug\";s:19:\"shortcodes-ultimate\";s:6:\"plugin\";s:43:\"shortcodes-ultimate/shortcodes-ultimate.php\";s:11:\"new_version\";s:5:\"5.1.1\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/shortcodes-ultimate/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/shortcodes-ultimate.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/shortcodes-ultimate/assets/icon-256x256.png?rev=1760590\";s:2:\"1x\";s:72:\"https://ps.w.org/shortcodes-ultimate/assets/icon-128x128.png?rev=1760590\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/shortcodes-ultimate/assets/banner-1544x500.jpg?rev=1760590\";s:2:\"1x\";s:74:\"https://ps.w.org/shortcodes-ultimate/assets/banner-772x250.jpg?rev=1760590\";}s:11:\"banners_rtl\";a:0:{}}s:28:\"widgets-in-menu/yawp-wim.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/widgets-in-menu\";s:4:\"slug\";s:15:\"widgets-in-menu\";s:6:\"plugin\";s:28:\"widgets-in-menu/yawp-wim.php\";s:11:\"new_version\";s:5:\"1.0.0\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/widgets-in-menu/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/widgets-in-menu.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/widgets-in-menu/assets/icon-256x256.png?rev=1013882\";s:2:\"1x\";s:68:\"https://ps.w.org/widgets-in-menu/assets/icon-128x128.png?rev=1013882\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/widgets-in-menu/assets/banner-772x250.png?rev=1013882\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"wp-html-block/wp-html-block.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wp-html-block\";s:4:\"slug\";s:13:\"wp-html-block\";s:6:\"plugin\";s:31:\"wp-html-block/wp-html-block.php\";s:11:\"new_version\";s:5:\"1.0.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wp-html-block/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/wp-html-block.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-html-block/assets/icon-256x256.png?rev=1315948\";s:2:\"1x\";s:66:\"https://ps.w.org/wp-html-block/assets/icon-128x128.png?rev=1315948\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:68:\"https://ps.w.org/wp-html-block/assets/banner-772x250.png?rev=1315948\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_last', '1'),
(4, 5, '_edit_lock', '1544508421:1'),
(7, 8, '_wp_attached_file', '2018/12/badmashiyaan-lawsuit-couples.jpg'),
(8, 8, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1000;s:6:\"height\";i:563;s:4:\"file\";s:40:\"2018/12/badmashiyaan-lawsuit-couples.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"badmashiyaan-lawsuit-couples-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"badmashiyaan-lawsuit-couples-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"badmashiyaan-lawsuit-couples-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:32:\"twentyseventeen-thumbnail-avatar\";a:4:{s:4:\"file\";s:40:\"badmashiyaan-lawsuit-couples-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(9, 9, '_wp_trash_meta_status', 'publish'),
(10, 9, '_wp_trash_meta_time', '1544514222'),
(11, 10, '_wp_trash_meta_status', 'publish'),
(12, 10, '_wp_trash_meta_time', '1544514269'),
(13, 11, '_wp_trash_meta_status', 'publish'),
(14, 11, '_wp_trash_meta_time', '1544514289'),
(32, 3, '_wp_trash_meta_status', 'draft'),
(33, 3, '_wp_trash_meta_time', '1544708136'),
(34, 3, '_wp_desired_post_slug', 'privacy-policy'),
(35, 2, '_wp_trash_meta_status', 'publish'),
(36, 2, '_wp_trash_meta_time', '1544708136'),
(37, 2, '_wp_desired_post_slug', 'sample-page'),
(38, 16, '_edit_last', '1'),
(39, 17, '_menu_item_type', 'post_type'),
(40, 17, '_menu_item_menu_item_parent', '0'),
(41, 17, '_menu_item_object_id', '16'),
(42, 17, '_menu_item_object', 'page'),
(43, 17, '_menu_item_target', ''),
(44, 17, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(45, 17, '_menu_item_xfn', ''),
(46, 17, '_menu_item_url', ''),
(47, 16, '_edit_lock', '1544708027:1'),
(48, 19, '_edit_last', '1'),
(49, 20, '_menu_item_type', 'post_type'),
(50, 20, '_menu_item_menu_item_parent', '0'),
(51, 20, '_menu_item_object_id', '19'),
(52, 20, '_menu_item_object', 'page'),
(53, 20, '_menu_item_target', ''),
(54, 20, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(55, 20, '_menu_item_xfn', ''),
(56, 20, '_menu_item_url', ''),
(57, 19, '_edit_lock', '1544708044:1'),
(58, 22, '_edit_last', '1'),
(59, 23, '_menu_item_type', 'post_type'),
(60, 23, '_menu_item_menu_item_parent', '0'),
(61, 23, '_menu_item_object_id', '22'),
(62, 23, '_menu_item_object', 'page'),
(63, 23, '_menu_item_target', ''),
(64, 23, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(65, 23, '_menu_item_xfn', ''),
(66, 23, '_menu_item_url', ''),
(67, 22, '_edit_lock', '1544708057:1'),
(68, 25, '_edit_last', '1'),
(69, 26, '_menu_item_type', 'post_type'),
(70, 26, '_menu_item_menu_item_parent', '0'),
(71, 26, '_menu_item_object_id', '25'),
(72, 26, '_menu_item_object', 'page'),
(73, 26, '_menu_item_target', ''),
(74, 26, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(75, 26, '_menu_item_xfn', ''),
(76, 26, '_menu_item_url', ''),
(77, 25, '_edit_lock', '1544708075:1'),
(78, 28, '_edit_last', '1'),
(79, 29, '_menu_item_type', 'post_type'),
(80, 29, '_menu_item_menu_item_parent', '0'),
(81, 29, '_menu_item_object_id', '28'),
(82, 29, '_menu_item_object', 'page'),
(83, 29, '_menu_item_target', ''),
(84, 29, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(85, 29, '_menu_item_xfn', ''),
(86, 29, '_menu_item_url', ''),
(87, 28, '_edit_lock', '1544708094:1'),
(88, 31, '_edit_last', '1'),
(89, 32, '_menu_item_type', 'post_type'),
(90, 32, '_menu_item_menu_item_parent', '0'),
(91, 32, '_menu_item_object_id', '31'),
(92, 32, '_menu_item_object', 'page'),
(93, 32, '_menu_item_target', ''),
(94, 32, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(95, 32, '_menu_item_xfn', ''),
(96, 32, '_menu_item_url', ''),
(97, 31, '_edit_lock', '1544708106:1'),
(98, 34, '_edit_last', '1'),
(99, 35, '_menu_item_type', 'post_type'),
(100, 35, '_menu_item_menu_item_parent', '0'),
(101, 35, '_menu_item_object_id', '34'),
(102, 35, '_menu_item_object', 'page'),
(103, 35, '_menu_item_target', ''),
(104, 35, '_menu_item_classes', 'a:1:{i:0;s:13:\"has-mega-menu\";}'),
(105, 35, '_menu_item_xfn', ''),
(106, 35, '_menu_item_url', ''),
(107, 34, '_edit_lock', '1544708114:1'),
(117, 17, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(118, 20, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(119, 23, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(120, 26, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(121, 29, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(122, 32, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(123, 35, '_menu_item_wpmi', 'a:6:{s:5:\"label\";i:0;s:8:\"position\";s:6:\"before\";s:5:\"align\";s:6:\"middle\";s:4:\"size\";s:1:\"1\";s:4:\"icon\";s:0:\"\";s:5:\"color\";s:0:\"\";}'),
(133, 17, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(134, 20, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(135, 23, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(136, 26, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(137, 29, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(138, 32, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(139, 35, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(142, 42, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(143, 42, '_edit_last', '1'),
(144, 42, '_edit_lock', '1544724584:1'),
(145, 43, '_wpb_vc_js_status', 'false'),
(146, 43, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(147, 43, '_menu_item_type', 'post_type'),
(148, 43, '_menu_item_menu_item_parent', '29'),
(149, 43, '_menu_item_object_id', '42'),
(150, 43, '_menu_item_object', 'page'),
(151, 43, '_menu_item_target', ''),
(152, 43, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(153, 43, '_menu_item_xfn', ''),
(154, 43, '_menu_item_url', ''),
(155, 42, '_wpb_vc_js_status', 'false'),
(156, 45, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(157, 45, '_edit_last', '1'),
(158, 45, '_edit_lock', '1544725660:1'),
(159, 46, '_wpb_vc_js_status', 'false'),
(160, 46, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(161, 46, '_menu_item_type', 'post_type'),
(162, 46, '_menu_item_menu_item_parent', '29'),
(163, 46, '_menu_item_object_id', '45'),
(164, 46, '_menu_item_object', 'page'),
(165, 46, '_menu_item_target', ''),
(166, 46, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(167, 46, '_menu_item_xfn', ''),
(168, 46, '_menu_item_url', ''),
(169, 45, '_wpb_vc_js_status', 'false'),
(170, 43, 'menu-icons', 'a:8:{s:4:\"type\";s:2:\"fa\";s:4:\"icon\";s:10:\"fa-history\";s:10:\"hide_label\";s:0:\"\";s:8:\"position\";s:6:\"before\";s:14:\"vertical_align\";s:6:\"middle\";s:9:\"font_size\";s:3:\"1.2\";s:9:\"svg_width\";s:1:\"1\";s:10:\"image_size\";s:9:\"thumbnail\";}'),
(171, 46, 'menu-icons', 'a:8:{s:4:\"type\";s:2:\"fa\";s:4:\"icon\";s:5:\"fa-th\";s:10:\"hide_label\";s:0:\"\";s:8:\"position\";s:6:\"before\";s:14:\"vertical_align\";s:6:\"middle\";s:9:\"font_size\";s:3:\"1.2\";s:9:\"svg_width\";s:1:\"1\";s:10:\"image_size\";s:9:\"thumbnail\";}'),
(172, 48, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(173, 48, '_edit_last', '1'),
(174, 48, '_edit_lock', '1544725048:1'),
(175, 48, '_htmlblock_description', ''),
(176, 48, '_htmlblock_wrapper_class', ''),
(177, 48, '_htmlblock_active', 'Yes'),
(178, 48, '_htmlblock_display_title', 'No'),
(179, 48, '_htmlblock_display_desc', 'No'),
(180, 48, '_htmlblock_include_img', 'No'),
(181, 48, '_htmlblock_img_location', 'Top'),
(182, 48, '_htmlblock_img_size', 'thumbnail'),
(193, 48, '_wp_trash_meta_status', 'publish'),
(194, 48, '_wp_trash_meta_time', '1544725191'),
(195, 48, '_wp_desired_post_slug', 'megamenu'),
(225, 53, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(226, 54, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(227, 55, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(228, 56, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(229, 57, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(230, 58, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(231, 59, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(232, 60, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(233, 61, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(234, 62, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(235, 63, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(236, 64, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(237, 65, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(238, 66, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(239, 67, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(240, 68, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(241, 69, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(242, 70, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(243, 70, '_edit_last', '1'),
(244, 70, '_edit_lock', '1544801643:1'),
(245, 71, '_wp_attached_file', '2018/12/banner2.jpg'),
(246, 71, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:19:\"2018/12/banner2.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"banner2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"banner2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"banner2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"banner2-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(247, 70, '_thumbnail_id', '71'),
(248, 70, '_slider_slider_title', 'sfdsfdsfdsf'),
(249, 70, '_slider_title', 'Welcome To'),
(250, 70, '_slider_heading', 'Unique IT insittute'),
(251, 70, '_slider_ptext', 'This example replicates the default render method with custom classes assigned to wrapping divs and the original cmb-row class removed as an example.'),
(254, 70, '_slider_btn_text1', 'OUR COURSES'),
(255, 72, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(256, 70, '_slider_btn_text2', 'CONTACT'),
(257, 70, '_slider_btn_url1', 'http://www.facebook.com'),
(258, 70, '_slider_btn_url2', 'http://www.facebook.com'),
(259, 73, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(260, 73, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(261, 73, '_edit_last', '1'),
(262, 73, '_edit_lock', '1544871840:1'),
(263, 73, '_thumbnail_id', '74'),
(264, 73, '_slider_slider_title', 'sfdsfdsfdsf'),
(265, 73, '_slider_title', 'Welcome To'),
(266, 73, '_slider_heading', 'Unique IT insittute'),
(267, 73, '_slider_ptext', 'This example replicates the default render method with custom classes assigned to wrapping divs and the original cmb-row class removed as an example.'),
(268, 73, '_slider_btn_text1', 'OUR COURSES'),
(269, 73, '_slider_btn_text2', 'CONTACT'),
(270, 73, '_slider_btn_url1', 'http://www.facebook.com'),
(271, 73, '_slider_btn_url2', 'http://www.facebook.com'),
(275, 74, '_wp_attached_file', '2018/12/c1.jpeg'),
(276, 74, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:895;s:4:\"file\";s:15:\"2018/12/c1.jpeg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"c1-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"c1-300x210.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:210;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"c1-768x537.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:537;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"c1-1024x716.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:716;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(277, 73, '_wp_old_slug', 'slider1'),
(278, 75, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(279, 75, '_menu_item_type', 'yawp_wim'),
(280, 75, '_menu_item_menu_item_parent', '20'),
(281, 75, '_menu_item_object_id', '2'),
(282, 75, '_menu_item_object', 'yawp_wim'),
(283, 75, '_menu_item_target', ''),
(284, 75, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(285, 75, '_menu_item_xfn', 'custom_html-2'),
(286, 75, '_menu_item_url', ''),
(288, 76, '_vc_post_settings', 'a:1:{s:10:\"vc_grid_id\";a:0:{}}'),
(289, 76, '_menu_item_type', 'yawp_wim'),
(290, 76, '_menu_item_menu_item_parent', '23'),
(291, 76, '_menu_item_object_id', '3'),
(292, 76, '_menu_item_object', 'yawp_wim'),
(293, 76, '_menu_item_target', ''),
(294, 76, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(295, 76, '_menu_item_xfn', 'custom_html-3'),
(296, 76, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-12-11 06:00:31', '2018-12-11 06:00:31', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2018-12-11 06:00:31', '2018-12-11 06:00:31', '', 0, 'http://localhost/unique/?p=1', 0, 'post', '', 1),
(2, 1, '2018-12-11 06:00:31', '2018-12-11 06:00:31', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/unique/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2018-12-13 13:35:36', '2018-12-13 13:35:36', '', 0, 'http://localhost/unique/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-12-11 06:00:31', '2018-12-11 06:00:31', '<h2>Who we are</h2><p>Our website address is: http://localhost/unique.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2018-12-13 13:35:36', '2018-12-13 13:35:36', '', 0, 'http://localhost/unique/?page_id=3', 0, 'page', '', 0),
(4, 1, '2018-12-11 06:00:45', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-12-11 06:00:45', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?p=4', 0, 'post', '', 0),
(5, 1, '2018-12-11 06:09:08', '2018-12-11 06:09:08', 'hi im sohidul islam.......i want to know about more wordpress', 'hello boss', '', 'publish', 'open', 'open', '', 'hello-boss', '', '', '2018-12-11 06:09:08', '2018-12-11 06:09:08', '', 0, 'http://localhost/unique/?p=5', 0, 'post', '', 0),
(6, 1, '2018-12-11 06:09:08', '2018-12-11 06:09:08', 'hi im sohidul islam.......i want to know about more wordpress', 'hello boss', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-11 06:09:08', '2018-12-11 06:09:08', '', 5, 'http://localhost/unique/2018/12/11/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2018-12-11 06:09:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-12-11 06:09:31', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?p=7', 0, 'post', '', 0),
(8, 1, '2018-12-11 07:43:15', '2018-12-11 07:43:15', '', 'badmashiyaan-lawsuit-couples', '', 'inherit', 'open', 'closed', '', 'badmashiyaan-lawsuit-couples', '', '', '2018-12-11 07:43:15', '2018-12-11 07:43:15', '', 0, 'http://localhost/unique/wp-content/uploads/2018/12/badmashiyaan-lawsuit-couples.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2018-12-11 07:43:42', '2018-12-11 07:43:42', '{\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [],\n            \"sidebar-1\": [\n                \"search-2\",\n                \"recent-posts-2\",\n                \"recent-comments-2\",\n                \"archives-2\",\n                \"categories-2\",\n                \"meta-2\"\n            ],\n            \"sidebar-2\": [],\n            \"sidebar-3\": []\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:43:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '346ce02f-5fc8-42d1-baa2-5dbc968061d3', '', '', '2018-12-11 07:43:42', '2018-12-11 07:43:42', '', 0, 'http://localhost/unique/2018/12/11/346ce02f-5fc8-42d1-baa2-5dbc968061d3/', 0, 'customize_changeset', '', 0),
(10, 1, '2018-12-11 07:44:29', '2018-12-11 07:44:29', '{\n    \"twentyfifteen::sidebar_textcolor\": {\n        \"value\": \"#8224e3\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:44:29\"\n    },\n    \"twentyfifteen::header_background_color\": {\n        \"value\": \"#c4c4c4\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:44:29\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '382bf341-37e9-49d9-8149-88e1d5a18ae8', '', '', '2018-12-11 07:44:29', '2018-12-11 07:44:29', '', 0, 'http://localhost/unique/2018/12/11/382bf341-37e9-49d9-8149-88e1d5a18ae8/', 0, 'customize_changeset', '', 0),
(11, 1, '2018-12-11 07:44:49', '2018-12-11 07:44:49', '{\n    \"twentyfifteen::background_color\": {\n        \"value\": \"#f4ca16\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:44:49\"\n    },\n    \"twentyfifteen::color_scheme\": {\n        \"value\": \"yellow\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:44:49\"\n    },\n    \"twentyfifteen::sidebar_textcolor\": {\n        \"value\": \"#111111\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:44:49\"\n    },\n    \"twentyfifteen::header_background_color\": {\n        \"value\": \"#ffdf00\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-12-11 07:44:49\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b870650f-0685-4e7e-b511-670b418fe6ec', '', '', '2018-12-11 07:44:49', '2018-12-11 07:44:49', '', 0, 'http://localhost/unique/2018/12/11/b870650f-0685-4e7e-b511-670b418fe6ec/', 0, 'customize_changeset', '', 0),
(14, 1, '2018-12-13 13:35:36', '2018-12-13 13:35:36', '<h2>Who we are</h2><p>Our website address is: http://localhost/unique.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2018-12-13 13:35:36', '2018-12-13 13:35:36', '', 3, 'http://localhost/unique/2018/12/13/3-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2018-12-13 13:35:36', '2018-12-13 13:35:36', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/unique/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-12-13 13:35:36', '2018-12-13 13:35:36', '', 2, 'http://localhost/unique/2018/12/13/2-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-12-13 13:35:48', '2018-12-13 13:35:48', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-12-13 13:35:48', '2018-12-13 13:35:48', '', 0, 'http://localhost/unique/?page_id=16', 0, 'page', '', 0),
(17, 1, '2018-12-13 13:35:48', '2018-12-13 13:35:48', ' ', '', '', 'publish', 'closed', 'closed', '', '17', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/17/', 1, 'nav_menu_item', '', 0),
(18, 1, '2018-12-13 13:35:48', '2018-12-13 13:35:48', '', 'Home', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-12-13 13:35:48', '2018-12-13 13:35:48', '', 16, 'http://localhost/unique/2018/12/13/16-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2018-12-13 13:36:17', '2018-12-13 13:36:17', '', 'Courses', '', 'publish', 'closed', 'closed', '', 'courses', '', '', '2018-12-13 13:36:17', '2018-12-13 13:36:17', '', 0, 'http://localhost/unique/?page_id=19', 0, 'page', '', 0),
(20, 1, '2018-12-13 13:36:17', '2018-12-13 13:36:17', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/20/', 2, 'nav_menu_item', '', 0),
(21, 1, '2018-12-13 13:36:17', '2018-12-13 13:36:17', '', 'Courses', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2018-12-13 13:36:17', '2018-12-13 13:36:17', '', 19, 'http://localhost/unique/2018/12/13/19-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-12-13 13:36:32', '2018-12-13 13:36:32', '', 'Services', '', 'publish', 'closed', 'closed', '', 'services', '', '', '2018-12-13 13:36:32', '2018-12-13 13:36:32', '', 0, 'http://localhost/unique/?page_id=22', 0, 'page', '', 0),
(23, 1, '2018-12-13 13:36:32', '2018-12-13 13:36:32', '[wphtmlblock id=\"48\"]', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/23/', 4, 'nav_menu_item', '', 0),
(24, 1, '2018-12-13 13:36:32', '2018-12-13 13:36:32', '', 'Services', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2018-12-13 13:36:32', '2018-12-13 13:36:32', '', 22, 'http://localhost/unique/2018/12/13/22-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2018-12-13 13:36:45', '2018-12-13 13:36:45', '', 'Galleries', '', 'publish', 'closed', 'closed', '', 'galleries', '', '', '2018-12-13 13:36:45', '2018-12-13 13:36:45', '', 0, 'http://localhost/unique/?page_id=25', 0, 'page', '', 0),
(26, 1, '2018-12-13 13:36:45', '2018-12-13 13:36:45', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/26/', 6, 'nav_menu_item', '', 0),
(27, 1, '2018-12-13 13:36:45', '2018-12-13 13:36:45', '', 'Galleries', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2018-12-13 13:36:45', '2018-12-13 13:36:45', '', 25, 'http://localhost/unique/2018/12/13/25-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2018-12-13 13:37:03', '2018-12-13 13:37:03', '', 'Students', '', 'publish', 'closed', 'closed', '', 'students', '', '', '2018-12-13 13:37:03', '2018-12-13 13:37:03', '', 0, 'http://localhost/unique/?page_id=28', 0, 'page', '', 0),
(29, 1, '2018-12-13 13:37:03', '2018-12-13 13:37:03', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/29/', 7, 'nav_menu_item', '', 0),
(30, 1, '2018-12-13 13:37:03', '2018-12-13 13:37:03', '', 'Students', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2018-12-13 13:37:03', '2018-12-13 13:37:03', '', 28, 'http://localhost/unique/2018/12/13/28-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2018-12-13 13:37:21', '2018-12-13 13:37:21', '', 'Tutorials', '', 'publish', 'closed', 'closed', '', 'tutorials', '', '', '2018-12-13 13:37:21', '2018-12-13 13:37:21', '', 0, 'http://localhost/unique/?page_id=31', 0, 'page', '', 0),
(32, 1, '2018-12-13 13:37:21', '2018-12-13 13:37:21', ' ', '', '', 'publish', 'closed', 'closed', '', '32', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/32/', 10, 'nav_menu_item', '', 0),
(33, 1, '2018-12-13 13:37:21', '2018-12-13 13:37:21', '', 'Tutorials', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2018-12-13 13:37:21', '2018-12-13 13:37:21', '', 31, 'http://localhost/unique/2018/12/13/31-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2018-12-13 13:37:34', '2018-12-13 13:37:34', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-12-13 13:37:34', '2018-12-13 13:37:34', '', 0, 'http://localhost/unique/?page_id=34', 0, 'page', '', 0),
(35, 1, '2018-12-13 13:37:34', '2018-12-13 13:37:34', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/35/', 11, 'nav_menu_item', '', 0),
(36, 1, '2018-12-13 13:37:34', '2018-12-13 13:37:34', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2018-12-13 13:37:34', '2018-12-13 13:37:34', '', 34, 'http://localhost/unique/2018/12/13/34-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2018-12-13 18:12:04', '2018-12-13 18:12:04', '', 'Student Works', '', 'publish', 'closed', 'closed', '', 'student-works', '', '', '2018-12-13 18:12:04', '2018-12-13 18:12:04', '', 0, 'http://localhost/unique/?page_id=42', 0, 'page', '', 0),
(43, 1, '2018-12-13 18:12:04', '2018-12-13 18:12:04', ' ', '', '', 'publish', 'closed', 'closed', '', '43', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/43/', 8, 'nav_menu_item', '', 0),
(44, 1, '2018-12-13 18:12:04', '2018-12-13 18:12:04', '', 'Student Works', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2018-12-13 18:12:04', '2018-12-13 18:12:04', '', 42, 'http://localhost/unique/2018/12/13/42-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-12-13 18:12:23', '2018-12-13 18:12:23', '', 'Student Success Story', '', 'publish', 'closed', 'closed', '', 'student-success-story', '', '', '2018-12-13 18:12:23', '2018-12-13 18:12:23', '', 0, 'http://localhost/unique/?page_id=45', 0, 'page', '', 0),
(46, 1, '2018-12-13 18:12:23', '2018-12-13 18:12:23', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/2018/12/13/46/', 9, 'nav_menu_item', '', 0),
(47, 1, '2018-12-13 18:12:23', '2018-12-13 18:12:23', '', 'Student Success Story', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2018-12-13 18:12:23', '2018-12-13 18:12:23', '', 45, 'http://localhost/unique/2018/12/13/45-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-12-13 18:15:55', '2018-12-13 18:15:55', '       <ul id=\"submenu\">\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"> <i class=\"fa fa-paint-brush\" aria-hidden=\"true\"></i>\r\n                                        Web Design & Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> Software\r\n                                        Development </a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-desktop\" aria-hidden=\"true\"></i>\r\n                                        App Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-bullhorn\" aria-hidden=\"true\"></i>\r\n                                        Domain & Hosting Registration</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-free-code-camp\" aria-hidden=\"true\"></i>\r\n                                        Software Customazition</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-search\" aria-hidden=\"true\"></i> SEO &\r\n                                        Internet Marketing</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-user-circle-o\" aria-hidden=\"true\"></i>\r\n                                        ERP Software Development</a></li>\r\n                                <li><a class=\"sub_men\" href=\"cuourse.html\"><i class=\"fa fa-mobile\" aria-hidden=\"true\"></i>\r\n                                        Multimedia & Graphic Design</a></li>\r\n                            </ul>', 'Megamenu', '', 'trash', 'closed', 'closed', '', 'megamenu__trashed', '', '', '2018-12-13 18:19:51', '2018-12-13 18:19:51', '', 0, 'http://localhost/unique/?post_type=html-block&#038;p=48', 0, 'html-block', '', 0),
(53, 1, '2018-12-14 14:40:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:40:25', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=53', 0, 'slider', '', 0),
(54, 1, '2018-12-14 14:43:25', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:43:25', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=54', 0, 'slider', '', 0),
(55, 1, '2018-12-14 14:44:18', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:44:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=55', 0, 'slider', '', 0),
(56, 1, '2018-12-14 14:45:20', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:45:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=56', 0, 'slider', '', 0),
(57, 1, '2018-12-14 14:50:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:50:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=57', 0, 'slider', '', 0),
(58, 1, '2018-12-14 14:50:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:50:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=58', 0, 'slider', '', 0),
(59, 1, '2018-12-14 14:51:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:51:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=59', 0, 'slider', '', 0),
(60, 1, '2018-12-14 14:52:37', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:52:37', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=60', 0, 'slider', '', 0),
(61, 1, '2018-12-14 14:52:42', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:52:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=61', 0, 'slider', '', 0),
(62, 1, '2018-12-14 14:53:54', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:53:54', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=62', 0, 'slider', '', 0),
(63, 1, '2018-12-14 14:54:24', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:54:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=63', 0, 'slider', '', 0),
(64, 1, '2018-12-14 14:55:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:55:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=64', 0, 'slider', '', 0),
(65, 1, '2018-12-14 14:55:43', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:55:43', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=65', 0, 'slider', '', 0),
(66, 1, '2018-12-14 14:56:12', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:56:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=66', 0, 'slider', '', 0),
(67, 1, '2018-12-14 14:57:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:57:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=67', 0, 'slider', '', 0),
(68, 1, '2018-12-14 14:58:09', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:58:09', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=68', 0, 'slider', '', 0),
(69, 1, '2018-12-14 14:59:06', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 14:59:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=69', 0, 'slider', '', 0),
(70, 1, '2018-12-14 15:03:21', '2018-12-14 15:03:21', '', 'slider1', '', 'publish', 'closed', 'closed', '', 'slider1', '', '', '2018-12-14 15:36:14', '2018-12-14 15:36:14', '', 0, 'http://localhost/unique/?post_type=slider&#038;p=70', 0, 'slider', '', 0),
(71, 1, '2018-12-14 15:04:08', '2018-12-14 15:04:08', '', 'banner2', '', 'inherit', 'open', 'closed', '', 'banner2', '', '', '2018-12-14 15:04:08', '2018-12-14 15:04:08', '', 70, 'http://localhost/unique/wp-content/uploads/2018/12/banner2.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2018-12-14 15:31:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-12-14 15:31:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/unique/?post_type=slider&p=72', 0, 'slider', '', 0),
(73, 1, '2018-12-14 15:36:51', '2018-12-14 15:36:51', '', 'slider1', '', 'publish', 'closed', 'closed', '', 'slider1-2', '', '', '2018-12-14 15:36:51', '2018-12-14 15:36:51', '', 0, 'http://localhost/unique/?post_type=slider&#038;p=73', 0, 'slider', '', 0),
(74, 1, '2018-12-14 15:36:44', '2018-12-14 15:36:44', '', 'c1', '', 'inherit', 'open', 'closed', '', 'c1', '', '', '2018-12-14 15:36:44', '2018-12-14 15:36:44', '', 73, 'http://localhost/unique/wp-content/uploads/2018/12/c1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 'Custom HTML', '', 'publish', 'closed', 'closed', '', 'custom-html', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/?p=75', 3, 'nav_menu_item', '', 0),
(76, 1, '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 'Custom HTML', '', 'publish', 'closed', 'closed', '', 'custom-html-2', '', '', '2018-12-14 15:38:47', '2018-12-14 15:38:47', '', 0, 'http://localhost/unique/?p=76', 5, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_menu_item_wpmi', 'fontawesome');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Header Menu', 'header-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 1, 0),
(17, 2, 0),
(20, 2, 0),
(23, 2, 0),
(26, 2, 0),
(29, 2, 0),
(32, 2, 0),
(35, 2, 0),
(43, 2, 0),
(46, 2, 0),
(75, 2, 0),
(76, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 11);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,vc_pointers_backend_editor'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:4:{s:64:\"e9f7f183783e017ad9f7c915ccd6bc11529c622a28561b46ff9cc11fa4206338\";a:4:{s:10:\"expiration\";i:1544866973;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1544694173;}s:64:\"103ee844631030de17b2509b588555daef958a6666b62dd3f8384b50b4b275f2\";a:4:{s:10:\"expiration\";i:1544876937;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1544704137;}s:64:\"bf419713f6bb317fe4e1c392bf5c73e6cbfa3783de5fda57e239f97413a3e2a7\";a:4:{s:10:\"expiration\";i:1544880795;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36\";s:5:\"login\";i:1544707995;}s:64:\"c51b016bc4672a90779cc940b899c2db4c00aa7faa6d85304a5cfa40aee59264\";a:4:{s:10:\"expiration\";i:1544971040;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0\";s:5:\"login\";i:1544798240;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'managenav-menuscolumnshidden', 'a:3:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:3:\"xfn\";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(20, 1, 'nav_menu_recently_edited', '2'),
(21, 1, 'wp_user-settings', 'editor=html&libraryContent=browse'),
(22, 1, 'wp_user-settings-time', '1544799849'),
(23, 1, 'closedpostboxes_slider', 'a:1:{i:0;s:10:\"postcustom\";}'),
(24, 1, 'metaboxhidden_slider', 'a:1:{i:0;s:7:\"slugdiv\";}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BUYVvnvycBO8oR65OOk9l4/C9Dl4OW0', 'admin', 'wweshahidul@gmial.com', '', '2018-12-11 06:00:31', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=322;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
